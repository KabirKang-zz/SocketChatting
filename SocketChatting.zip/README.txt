Kabir Kang
Assignment 1
CS 372

The programs should work perfectly. I have tested them in many ways to make sure they are robust. The only issue that ever happened was transferring from ONID to my local computer, the whitespace was messing up in python. I went through every line and redid the indentations.

To compile chatserve.cpp, type g++ chatserve.cpp -o chatserve

To use chatclient.py, type python chatclient.py 127.0.0.1 30003 or whatever port you want. I did my testing on the localhost as described in the prompt.

To execute chatserve which must be done first, type ./chatserve 30003 or whatever port you want. 
